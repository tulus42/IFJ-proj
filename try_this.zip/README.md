# IFJ PROJEKT 2018

Riešitelia:<br />
Adam Hostin, xhosti02<br />
Sabína Gregušová, xgregu02<br />
Dominik Peza, xpezad00<br />
Adrián Tulušák, xtulus00

TODO:<br />
lexer (testing) - Sabína <br />
parser - Aďo, Sabína <br />
hash-table - Adam <br />
instruction generator - Dominik
