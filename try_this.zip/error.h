/*
IFJ 2018
Adam Hostin, xhosti02
Sabína Gregušová, xgregu02
Dominik Peza, xpezad00
Adrián Tulušák, xtulus00
*/

#ifndef ERROR
#define ERROR

#define ER_LEX 1
#define ER_SYN 2
#define ER_SEM_VARIABLE 3
#define ER_SEM_TYPE 4
#define ER_SEM_PARAMETERS 5
#define ER_SEM_OTHER 6
#define ER_ZERO_DIV 9
#define ER_INTERNAL 99

#endif
